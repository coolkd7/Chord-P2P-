import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketImpl;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Node {
    chord frame;
    Socket clientSocket;
    private DataOutputStream dout;
    private DataInputStream din;
    private ServerSocket serverSocket;
    DataInputStream Sdin;
    DataOutputStream Sdout;
    Socket socketC;
    String detail;
    int nodeid;
    String nodeip;
    int nodeport;
    int Knownid;
    int Knownport;
    String Knownip;
    int predecessor_node_id = -1;
    String predecessor_node_ip = null;
    int predecessor_node_port = -1;
    String localhost="127.0.0.1";
    int successor_node_id = -1;
    String successor_node_ip = null;
    int successor_node_port = -1;
    String msg,m2,m3;
    String read1;
    String keys;
    String [][] finger=new String[4][3];
    int x,n1;
    void intialize()
    {
        listen(nodeport);
        auto_stablize();
        FingerTable();
    }
    void setUserDetail(int id,String ip,int port)
    {
     nodeid=id;
     nodeip=ip;
     nodeport=port;
    }
    void setKnownDetail(int id,String ip,int port)
    {
     Knownid=id;
     Knownip=ip;
     Knownport=port;
    }
    void join(int user,int knid)
    {
        System.out.println("join: ");
      if(knid==-1)
      {
        for(int i=1;i<=3;i++)
        {
            finger[i][2]=""+nodeid;
        }
        predecessor_node_id=nodeid;
        successor_node_id=nodeid;
      }
      else
      {
          System.out.println("join:known ");
        predecessor_node_id=-1;
        msg="Successor#"+user+"#"+knid+"#join";
        Send(Knownip,Knownport,msg);
        
      }
    }
    void find_Successor(String s1)
    {   
        System.out.println("find_Successor");
        String ss="";
        String a[]=new String [4];
        a=s1.split("#");
        int nk=find_predecessor(a[1]);
        System.out.println("s n:"+nk);
        if(nk==nodeid)
        {
            if(a[3].equals("join"))
            { 
                int aa=Integer.parseInt(a[1]);
                ss="Successer#"+successor_node_id;
                System.out.println("Successer_pre:s1: "+s1+"  . aa: "+(aa*1111));
                Send(localhost,(aa*1111),ss);
       
            }
            else
            {    
                System.out.println("s111: "+s1);
               int aa=Integer.parseInt(a[3]);
               ss="fSuccesser#"+successor_node_id+"#"+a[2];
               System.out.println("Stage 3 Predeser: "+nk);
               Send(localhost,aa*1111,ss);
            }
        }
        else
        {
            if(a[3].equals("join"))
            {
                ss="Successer1#"+nk+"#"+a[1];
                System.out.println("SS_pp: "+ss);
            }
            else
            {
                ss="fSuccesser1#"+a[2]+"#"+nk;
            }
            //System.out.println("Stage 4 Predeser: "+n);
            int n21=nk*1111;
            Send(localhost,n21,ss);
        }
    }
   int find_predecessor(String id)
   {
       System.out.println("find_predecessor");
       boolean b=true;
       int c1=0;
       n1=nodeid;
       int n2=Integer.parseInt(id);
       while(b==true){
           System.out.println("n111: "+n1+"  n2: "+n2);
       if(n1<successor_node_id){
         for(int i=(n1+1);i<=successor_node_id;i++)
         {
          if(i==n2){
              c1=1;
              b=false;
              System.out.println("i==n2");
          return n1;
         }
         }}
     else if(n1>successor_node_id)
     {
         
         c1=1;
        for(int i=(successor_node_id+1);i<n1;i++)
            {
                if(i==n2)
                {
                    c1=0;
                System.out.println("i1==n2");
                }
            }
        if(c1==1)
        {
            System.out.println("c1==1");
            b=false;
            return n1;
     } }
     else if(n1==successor_node_id)
     {
         System.out.println("c11==1");
         c1=1;
         b=false;
         return n1;
     }
     if(n1==nodeid)
     {
         n1 = find_closestprecedingfinger(n2);
     System.out.println("n11"+n1);
     }
         else {
              msg="fcp#"+n2+"#"+nodeid;
              Send(localhost,n1*1111,msg);
            }
       }
       System.out.println("i am out");
       return n1;
   }
    int find_closestprecedingfinger(int id)
   {  
       System.out.println("find_closestprecedingfinger: "+id);
       int c1=0;  //n
     int n1=nodeid;
     for(int i=3;i>0;i--)
     {
         int j1=Integer.parseInt(finger[i][2]);
         if(n1<id){
         for(int j=(n1+1);j<id;j++)
         {
          if(j==j1)
          {   c1=1;  //return finger
          return j1;
         }}
     }
     else if(n1>id)
     {
         c1=1;  //belong to
        for(int j=id;j<=n1;j++)
            {
                if(j==j1)
                c1=0;    //return n
            }
          if(c1==1)
            {
                return j1;
            }}
     }
     return n1;
   }
   
    void FingerTable()
    {
      finger[0][0]="Start";
      finger[0][1]="Interval";
      finger[0][2]="Successer";
      finger[1][0]=""+(nodeid+1)%8;
      finger[2][0]=""+(nodeid+2)%8;
      finger[3][0]=""+(nodeid+4)%8;
      finger[1][1]="[ "+(nodeid+1)%8+" , "+(nodeid+2)%8+" )";
      finger[2][1]="[ "+(nodeid+2)%8+" , "+(nodeid+4)%8+" )";
      finger[3][1]="[ "+(nodeid+4)%8+" , "+(nodeid)%8+" )";
    }
    void set_frame(chord t){
     frame = t;
 }

    
    void PrintFingerTable()
    {
        frame.table_set_null();
        for(int i=1;i<4;i++){
         for(int j=0;j<3;j++)
         {
             System.out.print(""+finger[i][j]+"     ");
         }System.out.print("\n");
         frame.table_add_item(finger[i][0],finger[i][1],finger[i][2]);
     }
    }
  void predecessor()
  {
      System.out.println("predecessor: "+predecessor_node_id);
  }
  void Successor()
  {
        System.out.println("Successor: "+successor_node_id);
  }
  
 void Stabllize()
  {
      System.out.println("Stablize");
   n1=nodeid;
   x=successor_node_id;
   if(nodeid!=x)
   {
   //System.out.println("X1: "+x);
   msg="predessor#"+x+"#"+nodeid+"#ree";
   //System.out.println("msg1: "+msg);
   Send(localhost,x*1111,msg);
   System.out.println("X2: "+x);
   }
   else{
        x=predecessor_node_id;
      }
   int ll=checkbelong(nodeid,successor_node_id,x);
        if(ll==1)
        {
            System.out.println("l11");
            successor_node_id=x;
        }     
       msg="notify#"+nodeid+"#ee#rr";
              //System.out.println("msg4: "+msg);
              Send(localhost,successor_node_id*1111,msg);
     }
  void notify(String id)
 {
     System.out.println("notify: "+id);
     //System.out.println("pre b: "+predecessor_node_id);
  int n11=Integer.parseInt(id);
  int ll=checkbelong(predecessor_node_id,nodeid,n11);
  if(predecessor_node_id==-1 ||  ll==1)
      predecessor_node_id=n11;
  
  //System.out.println("pre after: "+predecessor_node_id); //X1
 }
 void fix_finger()
 {
     System.out.println("fix_Finger: ");
     for(int i=1;i<4;i++)
     {
         int ch=0;
         int j1=Integer.parseInt(finger[i][0]);
         int kk=checkloop(nodeid,successor_node_id,j1);
         if(kk==1)
         {
            finger[i][2]=""+successor_node_id;
         }
         if(kk==0)
         {
            System.out.println("nullEntry");
           msg="finger#"+finger[i][0]+"#"+i+"#"+nodeid;
          Send(localhost,successor_node_id*1111,msg);
         }
 }
     System.out.println("over fix");
 }
 int checkbelong(int start,int end,int point)
 {
   if(start<end)
   {
     if(point>start && point<end)
     {
         return 1;
     }
     return 0;
   }
   else if(end<start)
   {
    if(point>start || point<end)
        return 1;
    return 0;
   }
   else if(end==start)
   {
       if(point==start)
           return 0;
   return 1;
   }
   return 0;
 }
 
 int checkloop(int start,int end,int point)
 {
   if(start<end)
   {
     if(point>=start && point<=end)
     {
         return 1;
     }
     return 0;
   }
   else if(end<start)
   {
    if(point>=start || point<=end)
        return 1;
    return 0;
   }
   else if(end==start)
   {
   return 1;
   }
   return 0;
 }
 
     void Send(String ip,int port,String msg){
        try {
            if(port!=nodeport)
            {
            System.out.println("Send ");
            //System.out.println("0");
            if(port>=0)
            {
            clientSocket = new Socket(ip,port);
            //System.out.println("1");
            dout = new DataOutputStream(clientSocket.getOutputStream());
            din = new DataInputStream(clientSocket.getInputStream());
            //System.out.println("2");
            dout.writeUTF(msg);
            //System.out.println("data sent");
           // read1=din.readUTF();
           // Messager(read1);
            //System.out.println("Read : "+read1);
            clientSocket.close();
           }
        }}
        catch (IOException ex) {
            Logger.getLogger(chord.class.getName()).log(Level.SEVERE, null, ex);
    
   }
 }
void keys()
{
     keys="";
  for(int i=0;i<50;i++)
     if(checkKeys(predecessor_node_id,nodeid,i%8)==1)
     {
       keys=keys+""+i+", ";
     }
  System.out.println("Keys: "+keys);
}
int checkKeys(int start,int end,int point)
 {
   if(start<end)//start predesor  end-node  
   {
     if(point>start && point<=end)
     {
         return 1;
     }
     return 0;
   }
   else if(end<start)//  3   7
   {
    if(point>start || point<=end)
        return 1;
    return 0;
   }
   else if(end==start)
   {
   return 1;
   }
   return 0;
 }

 void Messager(String msg) throws IOException
 {
     System.out.println("Messager: "+msg);
  String m1=msg.split("#")[0];
  if(m1.equals("Successor"))
  {
      //System.out.println("Stage 2");
    find_Successor(msg);
  }
  else if(m1.equals("Successer"))
  {
      successor_node_id=Integer.parseInt(msg.split("#")[1]);
  }
  else if(m1.equals("fSuccesser"))
  {
      int ii=Integer.parseInt(msg.split("#")[2]);
      finger[ii][2]=msg.split("#")[1];
  }
  else if(m1.equals("predessor"))
         {
             int ii=Integer.parseInt(msg.split("#")[2]);
             msg="predecessor_node_id#"+predecessor_node_id;
             Send(localhost,ii*1111,msg);
         }
  else if(m1.equals("Successer1"))
  {
      System.out.println("sss:msg: "+msg);
      int ii1=Integer.parseInt(msg.split("#")[2]);
      msg= "Successer#"+successor_node_id;
      Send(localhost,(ii1)*(1111),msg);
  }
  else if(m1.equals("fSuccesser1"))
  {
   msg= "fSuccesser#"+successor_node_id+"#"+msg.split("#")[1];
   int ii1=Integer.parseInt(msg.split("#")[2]);
   Send(localhost,ii1*1111,msg);
  }
  else if(m1.equals("predecessor_node_id"))
  {
    System.out.println("x11: "+x);
    x=Integer.parseInt(msg.split("#")[1]);
    System.out.println("x22: "+x);
  }
  else if(m1.equals("notify"))
    {//System.out.println("notify: "+msg);
        notify(msg.split("#")[1]);
    }
  else if(m1.equals("finger"))
  {
      find_Successor(msg);
      System.out.println("Finger: "+msg);
  }
  else if(m1.equals("fcp"))
  { 
      int k=Integer.parseInt(msg.split("#")[1]);
      n1=find_closestprecedingfinger(k);
      if(n1==nodeid)
      {
        msg="fcp1#"+n1+"#"+msg.split("#")[2];
        int p=Integer.parseInt(msg.split("#")[2]);
        Send(localhost,p*1111,msg);
      }
      else
      {
        msg="fcp#"+msg.split("#")[1]+"#"+msg.split("#")[2];
        Send(localhost,n1*1111,msg);
      }
      //System.out.println("Finger: "+msg);
  }
  else if(m1.equals("fcp1"))
          {
            n1=Integer.parseInt(msg.split("#")[1]);
          }
 }
 void auto_stablize(){
           System.out.println("auto_stablize: ");
          Timer t = new Timer();
          int seconds = 5;
          TimerTask task= new TimerTask() {
              @Override
              public void run() {
                  Stabllize();
                  PrintFingerTable();
                  predecessor();
                  Successor();
                  keys();
                  frame.set_successor_details(successor_node_id);
                  frame.set_predeccesor_details(predecessor_node_id);
                  frame.set_key_container(keys);
                  fix_finger();
                  keys();
                  //System.out.println("calling my methods");
              }
          };
          t.scheduleAtFixedRate(task,0, seconds*1000);
    }
    
 
 
 void listen(int port){
        try {
            serverSocket = new ServerSocket(port);
            Runnable r;
            r = new Runnable() {
                @Override
                public void run() {
                    while(true){
                        try {
                            socketC = serverSocket.accept();
                            //System.out.println("Welcome");
                            Sdout =new DataOutputStream(socketC.getOutputStream());
                            //System.out.println("Accepting....");
                            Sdin = new DataInputStream(socketC.getInputStream());
                            detail = Sdin.readUTF();
                            Messager(detail); 
                            //System.out.println("Detail"+detail);
                            String s="i am server";
                            //System.out.println("out");
                            Sdout.writeUTF(s);
                            //System.out.println("out succeess");
                        } catch (IOException ex) {
                            Logger.getLogger(chord.class.getName()).log(Level.SEVERE, null, ex);
                        }}
                }};
            Thread t1 = new Thread(r);
            t1.start();
       //     //System.out.println("Sercver started");
        } catch (IOException ex) {
            Logger.getLogger(Node.class.getName()).log(Level.SEVERE, null, ex);
        }
 }
}
